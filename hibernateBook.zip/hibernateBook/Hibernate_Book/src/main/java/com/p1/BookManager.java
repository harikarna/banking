package com.p1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class BookManager 
{
	protected SessionFactory sessionFactory;
	
	protected void setup() {
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
            System.out.println(sessionFactory);
        } 
        catch (Exception ex) {
            System.out.println("Session Factory not created !");
            StandardServiceRegistryBuilder.destroy(registry);
        }
        }
	
	protected void exit()
	{
		sessionFactory.close();
	}
	
	protected void create()
	{
		Book book=new Book();
		//book.setId();
		book.setTitle("Harry Potter");
		book.setAuthor("J.K Rowling");
		book.setPrice(100.0f);
		
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		
		session.save(book);
		
		session.getTransaction().commit();
		session.close();
	}
	
	protected void read()
	{
		Session session=sessionFactory.openSession();
		
		long bookId=102;
		Book book =session.get(Book.class, bookId);
		
		System.out.println("Title: "+book.getTitle());
		System.out.println("Author: "+book.getAuthor());
		System.out.println("Price: "+book.getPrice());
		
		session.close();
	}
	
	protected void update()
	{
		
	}
	
	protected void delete()
	{
		
	}
	
	public static void main(String args[])
	{
		BookManager manager=new BookManager();
		
		manager.setup();
		manager.create();
		manager.read();
		manager.exit();
	}
}
