package accountctgops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mclasses.AccountCtg;

public class Seid 
{
	Connection conn;
	int ctg_Id;
	String category;
	public Seid(Connection conn)
	{
		this.conn=conn;
	}
	AccountCtg ai=new AccountCtg(ctg_Id,category);
	String q="SELECT * FROM accountctg WHERE ctg_Id=?";
	public void sid(int ctg_Id)
	{
		try
		{
			PreparedStatement pstmt=conn.prepareStatement(q);
			pstmt.setInt(1, ctg_Id);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				ai.category=rs.getString("category");
				System.out.println("Category: "+ai.getCategory());	
			}
			}
			
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
	}

}
