package accountctgops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import mclasses.AccountCtg;

public class Inactg
{
	Connection conn;
	int ctg_Id;
	String category;
	public Inactg(Connection conn)
	{
		this.conn=conn;
	}
	AccountCtg ai=new AccountCtg(ctg_Id,category);
	String q="INSERT INTO accountctg VALUES (?,?)";
	public void ival(int ctg_Id,String category)
	{
		PreparedStatement preparedstmt=null;
		try
		{
			preparedstmt=this.conn.prepareStatement(q);
			preparedstmt.setInt(1, ctg_Id);
			preparedstmt.setString(2, category);
			preparedstmt.execute();
		}
		catch(SQLException ob3)
		{
			System.err.println("got an exception");
			System.err.println(ob3.getMessage());
		}
	}

}
