package accountctgops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import mclasses.AccountCtg;
import mclasses.Customers;

public class Seall 
{
	Connection conn;
	int ctg_Id;
	String category;
	public Seall(Connection conn)
	{
		this.conn=conn;
	}
	AccountCtg ai=new AccountCtg(ctg_Id,category);
	String q="SELECT * FROM accountctg";
	public void sall()
	{
		try
		{
			PreparedStatement pstmt=conn.prepareStatement(q);
			
			ResultSet rs=pstmt.executeQuery();
			
			System.out.println("Cat_Id"+"\t"+"Cat_Name");
			while(rs.next())
			{
				ai.ctg_Id=rs.getInt("ctg_Id");
				ai.category=rs.getString("Category");
				
				System.out.println(ai.getCtg_Id()+"\t"+ai.getCategory());
				
			}
			}
			
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
		}

}
