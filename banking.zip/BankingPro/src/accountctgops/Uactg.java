package accountctgops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import mclasses.AccountCtg;

public class Uactg 
{
	Connection conn;
	int ctg_Id;
	String category;
	public Uactg(Connection conn)
	{
		this.conn=conn;
	}
	AccountCtg ai=new AccountCtg(ctg_Id,category);
	String q="UPDATE accountctg SET Category=? WHERE ctg_Id=?";
	PreparedStatement preparedstmt=null;
	public void uact(String category,int ctg_Id)
	{
		try
		{
			preparedstmt=conn.prepareStatement(q);
			preparedstmt.setString(1, category);
			preparedstmt.setInt(2, ctg_Id);
			preparedstmt.executeUpdate();
		}
		catch(SQLException obb)
		{
			System.err.println("got an exception");
			System.err.println(obb.getMessage());
	    }
	}

}
