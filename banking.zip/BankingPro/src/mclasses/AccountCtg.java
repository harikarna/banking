package mclasses;

public class AccountCtg 
{
	public AccountCtg(int ctg_Id, String category) {
		
		this.ctg_Id = ctg_Id;
		this.category = category;
	}
	public int ctg_Id;
	public String category;
	public int getCtg_Id() {
		return ctg_Id;
	}
	public void setCtg_Id(int ctg_Id) {
		this.ctg_Id = ctg_Id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

}
