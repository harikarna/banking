package mclasses;

public class Customers 
{
	public Customers(int cid, String name, int mob, String mailid) {
		this.cid = cid;
		this.name = name;
		this.mob = mob;
		this.mailid = mailid;
	}
	public int cid;
	public String name;
	public int mob;
	public String mailid;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMob() {
		return mob;
	}
	public void setMob(int mob) {
		this.mob = mob;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	@Override
	public String toString() {
		return "Customers [cid=" + cid + ", name=" + name + ", mob=" + mob + ", mailid=" + mailid + "]";
	}

}
