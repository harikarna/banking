package mclasses;

public class Login 
{
	
	int uid;
	String uname;
	int upwd;
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getUpwd() {
		return upwd;
	}
	public void setUpwd(int upwd) {
		this.upwd = upwd;
	}
	

}
