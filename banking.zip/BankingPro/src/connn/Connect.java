package connn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect 
{
	Connection conn;
	
	String myUrl="jdbc:mysql://localhost:3306/sakila";
	public Connect()
	{}
	public Connection gc()
	{
		
		try
		{
		conn=DriverManager.getConnection(myUrl,"root","caroot");
		}
		catch(SQLException e)
		{
		e.printStackTrace();	
		}
		return conn;
	
}}
