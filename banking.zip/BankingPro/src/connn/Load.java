package connn;

public class Load 
{
	public void driver()
	{
	String myDriver="com.mysql.cj.jdbc.Driver";
	try
	{
		Class.forName(myDriver);
	}
	catch(ClassNotFoundException ob1)
	{
		System.out.println("Cannot load driver "+ob1);	
	}

}}
