package bankingops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import mclasses.Banking;

public class Ibank 
{
	Connection conn;
	int cid;
	int acc_no;
	int ctg_Id;
	String dateofinit;
	double accbal;
	public Ibank(Connection conn)
	{
		this.conn=conn;
	}
	//Date dta=new Date();
	
	Banking bi=new Banking(acc_no,cid,ctg_Id,dateofinit,accbal);
	public void ibnk(int cid,int acc_no,int ctg_Id,String dateofinit,double accbal)
	{
		String query="INSERT INTO banking VALUES (?,?,?,?,?)";
		PreparedStatement preparedstmt=null;
		try
		{
			preparedstmt=this.conn.prepareStatement(query);
			preparedstmt.setInt(1, cid);
			preparedstmt.setInt(2, acc_no);
			preparedstmt.setInt(3, ctg_Id);
			preparedstmt.setString(4, dateofinit);
			preparedstmt.setDouble(5, accbal);
			preparedstmt.execute();
			//conn.close();
		}
		catch(SQLException ob3)
		{
			System.err.println("got an exception");
			System.err.println(ob3.getMessage());
		}
	}

	

}
