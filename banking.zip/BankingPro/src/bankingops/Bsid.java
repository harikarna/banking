package bankingops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mclasses.Banking;

public class Bsid 
{
	Connection conn;
	int cid;
	int acc_no;
	int ctg_Id;
	String dateofinit;
	int accbal;
	public Bsid(Connection conn)
	{
		this.conn=conn;
	}
	Banking bi=new Banking(acc_no,cid,ctg_Id,dateofinit,accbal);
	String q1="SELECT * FROM banking WHERE acc_no=?";
	public int bbal(int accno)
	{
		try
		{
			PreparedStatement pstmt=conn.prepareStatement(q1);
			pstmt.setInt(1, accno);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				//bi.cid=rs.getInt("cid");
				//bi.ctg_Id=rs.getInt("ctg_Id");
				//bi.dateofinit=rs.getString(dateofinit);
				bi.accbal=rs.getDouble("accbal");
				
				System.out.print("[Available Balance: "+bi.getAccbal());	
				
				
			}
			}
			
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
		
		return accbal;
		
		
	}
	
}
