package bankingops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import mclasses.Banking;

public class Wbal 
{
	Scanner qw=new Scanner(System.in);
	Connection conn;
	
	double a;
	int cid;
	int did;
	int acc_no;
	int ctg_Id;
	String dateofinit;
	double accbal;
	public Wbal(Connection conn)
	{
		this.conn=conn;
	}
	Banking bi=new Banking(acc_no,cid,ctg_Id,dateofinit,accbal);
	
	PreparedStatement preparedstmt=null;
	public void wdraw(int accno)
	{
		
		System.out.println("Enter Withdraw Amount");
		a=qw.nextDouble();
		String u1="UPDATE banking SET accbal=accbal-"+a+" WHERE acc_no=?";
		try
		{
			
			
			preparedstmt=conn.prepareStatement(u1);
			preparedstmt.setDouble(1, accno);
			//preparedstmt.setInt(2, accno);
			preparedstmt.executeUpdate();
			System.out.println("Rs."+a+" is Withdrawed");
			
		}
		catch(SQLException obb)
		{
			System.err.println("got an exception");
			System.err.println(obb.getMessage());
	    }
	}

}
