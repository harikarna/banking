package bankingops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mclasses.Banking;
import mclasses.Customers;

public class Disall 
{
	Connection conn;
	int cid;
	int acc_no;
	int ctg_Id;
	String dateofinit;
	double accbal;
	public Disall(Connection conn)
	{
		this.conn=conn;
	}
	Banking bi=new Banking(acc_no,cid,ctg_Id,dateofinit,accbal);
	String q="SELECT * FROM banking";
	public void dall()
	{
		try
		{
			PreparedStatement pstmt=conn.prepareStatement(q);
			
			ResultSet rs=pstmt.executeQuery();
			
			System.out.println("Acc-No"+"\t"+"Cust-Id"+"\t"+"Ctg-Id"+"\t"+"Date"+"\t"+"AccBal");
			while(rs.next())
			{
				bi.acc_no=rs.getInt("acc_no");
				bi.cid=rs.getInt("cid");
				bi.ctg_Id=rs.getInt("ctg_Id");
				bi.dateofinit=rs.getString("dateofinit");
				bi.accbal=rs.getDouble("accbal");
				System.out.println(bi.getAcc_no()+"\t"+bi.getCid()+"\t"+bi.getCtg_Id()+"\t"+bi.getDateofinit()+"\t  "+bi.getAccbal());
				
			}
			}
			
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
		}

}
