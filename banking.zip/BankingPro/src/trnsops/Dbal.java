package trnsops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import mclasses.Banking;
import mclasses.Transactions;

public class Dbal
{
	Scanner qw=new Scanner(System.in);
	Connection conn;
	
	double a;
	double accbal;
	public int Trn_Id;
	public int acc_no;
	public String Trn_date;
	public double amount;
	public String comments;
	public Dbal(Connection conn)
	{
		this.conn=conn;
	}
	//Banking bi=new Banking(acc_no,cid,ctg_Id,dateofinit,accbal);
	Transactions ti=new Transactions(Trn_Id,acc_no,Trn_date,amount,comments);
	PreparedStatement preparedstmt=null;
	public void depi(int accno)
	{
		System.out.println("Enter Deposit Amount");
	    double amount=qw.nextDouble();
		
		
		String u1="UPDATE banking SET accbal=accbal+"+amount+" WHERE acc_no=?";
		try
		{
			preparedstmt=conn.prepareStatement(u1);
			preparedstmt.setInt(1, accno);
			
			preparedstmt.executeUpdate();
			System.out.print("Rs."+amount+" is deposited ");
		}
		catch(SQLException obb)
		{
			System.err.println("got an exception");
			System.err.println(obb.getMessage());
	    }
	}
	
	

}
