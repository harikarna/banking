package trnsops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mclasses.Customers;
import mclasses.Transactions;

public class Trnsid 
{
	Connection conn;
	String s1=" ";
	public int Trn_Id;
	public int acc_no;
	public String Trn_date;
	public double amount;
	public String comments;
	Dbal d2=new Dbal(conn);
	public Trnsid(Connection conn)
	{
		this.conn=conn;
		this.amount=amount;
	}
	Transactions ti=new Transactions(Trn_Id,acc_no,Trn_date,amount,comments);
	String q1="SELECT * FROM transactions WHERE acc_no=? and Trn_date between ? and ?";
	public void tid(int acc_no,String Trn_date,String s1)
	{
		try
		{
			PreparedStatement pstmt=conn.prepareStatement(q1);
			pstmt.setInt(1, acc_no);
			pstmt.setString(2, Trn_date);
			pstmt.setString(3, s1);
			ResultSet rs=pstmt.executeQuery();
			System.out.println("TrnsId"+"\t"+"Amount"+"\t"+"Comments");
			while(rs.next())
			{
				ti.Trn_Id=rs.getInt("Trn_Id");
				ti.amount=rs.getInt("amount");
				ti.comments=rs.getString("comments");
				System.out.println(ti.getTrn_Id()+"  \t "+ti.getAmount()+"\t"+ti.getComments());	
			}
			}
			
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
	}
}
