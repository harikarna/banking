package trnsops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import mclasses.Customers;
import mclasses.Login;

public class Auth 
{
	Connection conn;
	
	Scanner qw=new Scanner(System.in);
	int uid;
	String uname;
	int upwd;
	int p=0;
	public Auth(Connection conn)
	{
		this.conn=conn;
	}
	Login li=new Login(uid,uname,upwd);
	String q1="SELECT * FROM logins WHERE uname=? and upwd=?";
	
	public int lo()
	{
		try
		{
			System.out.print("Enter UserName:");
			uname=qw.next();
			System.out.print("Enter Password:");
			upwd=qw.nextInt();
			
			PreparedStatement pstmt=conn.prepareStatement(q1);
			pstmt.setString(1,uname);
			pstmt.setInt(2, upwd);
			ResultSet rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				p=1;}
			if(p==1) {
				System.out.println("---Login Successfull---");	
				return p;
				}
				else {
					System.out.println("---Invalid Credentials(TRY AGAIN)---");
					lo();
					return p;}
					
			
			}
			
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
		return p;
	}

}
