package trnsops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import mclasses.Banking;
import mclasses.Transactions;

public class Wbal 
{
	Scanner qw=new Scanner(System.in);
	Connection conn;
	
	double a;
	double accbal;
	public int Trn_Id;
	public int acc_no;
	public String Trn_date;
	public double amount;
	public String comments;
	public Wbal(Connection conn)
	{
		this.conn=conn;
	}

	Transactions ti=new Transactions(Trn_Id,acc_no,Trn_date,amount,comments);
	PreparedStatement preparedstmt=null;
	public void wdraw(int accno)
	{
		
		System.out.print("Enter Withdraw Amount:");
		amount=qw.nextDouble();
		String u1="UPDATE banking SET accbal=accbal-"+amount+" WHERE acc_no=?";
		try
		{
			
			
			preparedstmt=conn.prepareStatement(u1);
			preparedstmt.setDouble(1, accno);
			//preparedstmt.setInt(2, accno);
			preparedstmt.executeUpdate();
			System.out.println("Rs."+amount+" is Withdrawed");
			
		}
		catch(SQLException obb)
		{
			System.err.println("got an exception");
			System.err.println(obb.getMessage());
	    }
	}
	
	
}
