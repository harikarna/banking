package mainnn;


import trnsops.Auth;
import trnsops.Dbal;

import trnsops.Trnsid;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;
import accountctgops.Inactg;
import accountctgops.Seall;
import accountctgops.Seid;
import accountctgops.Uactg;
import bankingops.Bsbal;
import bankingops.Bsid;
//import bankingops.Dbal;
import bankingops.Disall;
import bankingops.Ibank;
import bankingops.Wbal;
import connn.Connect;
import connn.Load;
import customerops.Delid;
import customerops.Insert;
import customerops.Selectall;
import customerops.SelectbyId;
import customerops.Updatemailid;
import customerops.Updatemob;
import customerops.Updatename;
import mclasses.Transactions;
import mclasses.Transactions;
public class Bapp {

	public static void main(String[] args) 
	{
		
		Scanner qw=new Scanner(System.in);
		int ch,cus;
		boolean st=true;
		
		
		
		Connect c=new Connect();
		Load l=new Load();
		Connection conn=c.gc();
		//public void daate()
		//{
		//Date dat=new Date();
		//SimpleDateFormat dateForm = new SimpleDateFormat("yyyy/MM/dd");}
		Selectall s=new Selectall(conn);
		SelectbyId s1=new SelectbyId(conn);
		
		Insert i1=new Insert(conn);
		
		Updatename u1=new Updatename(conn);
		
		Updatemailid u2=new Updatemailid(conn);
		
		Updatemob u3=new Updatemob(conn);
		
		Seall a1=new Seall(conn);
		
		Seid a2=new Seid(conn);
		
		Inactg a3=new Inactg(conn);
		
		Uactg a4=new Uactg(conn);
		
		Disall d1=new Disall(conn);
		
		Bsid b1=new Bsid(conn);
		
		Dbal d2=new Dbal(conn);
		
		Wbal w1=new Wbal(conn);
		
		Delid du=new Delid(conn);
		Bsbal bt=new Bsbal(conn);
		Trnsid t1=new Trnsid(conn);
		Ibank ibb=new Ibank(conn);
		
		
		Auth au=new Auth(conn);
		int tt=au.lo();
		if(tt==1) {
		while(st) {
			
		System.out.println("CHOOSE:1.Create New Account 2.Customers 3.Banking 4.Transactions 5.Exit");
		ch=qw.nextInt();
		switch(ch)
		{
		case 1:System.out.print("Enter Account No:");
		   int acno=qw.nextInt();
		   System.out.print("Enter Customer Id:");
		   int acid=qw.nextInt();
		   System.out.print("Enter Category Id:");
		   int aid=qw.nextInt();
		   System.out.print("Enter Date:");
		   String da=qw.next();
		   System.out.print("Enter Opening Balance:");
		   double ob=qw.nextDouble();
		   ibb.ibnk(acno, acid, aid, da, ob);
		   System.out.println("-----New Account Created-----");
	   	   System.out.println(" ");
	   	   break;
		
		case 2:System.out.println("1.Insert Customer 2.Select By Id 3.Update Name 4.Display All");
				cus=qw.nextInt();
				switch(cus)
				{
				
				case 1:System.out.print("Enter Customer ID:");
					   int cid=qw.nextInt();
					   System.out.print("Enter Customer Name:");
					   String name=qw.next();
					   System.out.print("Enter Mobile No:");
					   int no=qw.nextInt();
					   System.out.print("Enter Mail Id:");
					   String mid=qw.next();
					   i1.ival(cid, name, no, mid);
					   System.out.println("-----New Customer Added-----");
				   	   System.out.println(" ");
				   	   break;
				
				case 2:System.out.print("Enter Customer ID:");
				       int id=qw.nextInt();
				       s1.sid(id);
				       System.out.println("-----Id Details Displayed-----");
				   	   System.out.println(" ");
				   	   break;
				
				case 3:System.out.print("Enter Customer ID:");
			          int ciid=qw.nextInt();
			          System.out.print("Enter Name to Update:");
			          String cd=qw.next();
			          u1.uname(cd,ciid);
			          System.out.println("-----Customer Name Updated-----");
			   	      System.out.println(" ");
			   	      break; 	   
				  	   
				case 4:s.sall();
				       System.out.println("-----All Customers Displayed-----");
			   	       System.out.println(" ");
					   break;
				}
				break;
		case 3:System.out.println("SELECT:- 1.Select by Acc_No 2.Display All");
				int bus=qw.nextInt();
				switch(bus)
				{
				case 1:System.out.print("Enter AccNo:");
			          int acn=qw.nextInt();
			          bt.bba(acn);
			          System.out.println("-----Account Details Displayed-----");
			   	      System.out.println(" ");
			   	      break;
				case 2:d1.dall();
					 System.out.println("-----All Account Details Displayed-----");
		   	      	 System.out.println(" ");
					   break;    
				}
				break;
		case 4:System.out.println("SELECT:- 1.Deposit 2.Withdraw 3.View Transactions");
		       int trns=qw.nextInt();
		       switch(trns)
		       {
		       case 1:System.out.print("Enter Acc No. to Deposit Amount:");
				      int did=qw.nextInt();
				      d2.depi(did);
				      System.out.println(b1.bbal(did));
				      System.out.println(" ");
				      break;
		       case 2:System.out.print("Enter Acc No. to Withdraw Amount:");
			          int wid=qw.nextInt();
			          
			          w1.wdraw(wid);;
			          System.out.println(b1.bbal(wid));
			          System.out.println(" ");
			          break;
		       case 3:System.out.print("Enter Acc No. to view Transactions:");
		       		  int ano=qw.nextInt();
		       		  System.out.print("Enter Start Date: ");
		       		  String sd=qw.next();
		       		  System.out.print("Enter End Date: ");
		       		  String ed=qw.next();
		       		  System.out.println(" ");
		       		  t1.tid(ano, sd, ed);
		       		  System.out.println("-----Transcations Details Displayed-----");
		   	      	  System.out.println(" ");
		   	      	  break;
		       }
		       break;
		       
		case 5:st=false;
				System.out.println("---Thank you for Banking---");
				break;
				
		}
		}
		
		
	}
		

}}
