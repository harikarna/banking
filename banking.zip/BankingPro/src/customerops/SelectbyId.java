package customerops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mclasses.Customers;

public class SelectbyId
{
	Connection conn;
	int cid;
	String name;
	int mob;
	String mailid;
	public SelectbyId(Connection conn)
	{
		this.conn=conn;
	}
	Customers ci=new Customers(cid,name,mob,mailid);
	String q1="SELECT * FROM customers WHERE cid=?";
	public void sid(int cid)
	{
		try
		{
			PreparedStatement pstmt=conn.prepareStatement(q1);
			pstmt.setInt(1, cid);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				ci.name=rs.getString("name");
				ci.mob=rs.getInt("mob");
				ci.mailid=rs.getString("mail_id");
				System.out.println("CustName: "+ci.getName()+"\t"+"MobileNo: "+ci.getMob()+"  MailId: "+ci.getMailid());	
			}
			}
			
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
	}
}
