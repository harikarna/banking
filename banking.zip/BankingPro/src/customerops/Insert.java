package customerops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Insert 
{
	Connection conn;
	int cid;
	String name;
	int mob;
	String mailid;
	public Insert(Connection conn)
	{
		this.conn=conn;
	}
	public void ival(int cid,String name,int mob,String mailid)
	{
		String query="INSERT INTO customers VALUES (?,?,?,?)";
		PreparedStatement preparedstmt=null;
		try
		{
			preparedstmt=this.conn.prepareStatement(query);
			preparedstmt.setInt(1, cid);
			preparedstmt.setString(2, name);
			preparedstmt.setInt(3, mob);
			preparedstmt.setString(4, mailid);
			preparedstmt.execute();
			//conn.close();
		}
		catch(SQLException ob3)
		{
			System.err.println("got an exception");
			System.err.println(ob3.getMessage());
		}
	}

}
