package customerops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import mclasses.Customers;

public class Updatename 
{
	Connection conn;
	int cid;
	String name;
	int mob;
	String mailid;
	public Updatename(Connection conn)
	{
		this.conn=conn;
	}
	Customers ci=new Customers(cid,name,mob,mailid);
	String u1="UPDATE customers SET name=? WHERE cid=?";
	PreparedStatement preparedstmt=null;
	public void uname(String name,int cid)
	{
		try
		{
			preparedstmt=conn.prepareStatement(u1);
			preparedstmt.setString(1, name);
			preparedstmt.setInt(2, cid);
			preparedstmt.executeUpdate();
		}
		catch(SQLException obb)
		{
			System.err.println("got an exception");
			System.err.println(obb.getMessage());
	    }
	}

}
