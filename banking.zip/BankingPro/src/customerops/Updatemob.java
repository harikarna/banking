package customerops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import mclasses.Customers;

public class Updatemob 
{
	Connection conn;
	int cid;
	String name;
	int mob;
	String mailid;
	public Updatemob(Connection conn)
	{
		this.conn=conn;
	}
	Customers ci=new Customers(cid,name,mob,mailid);
	String u1="UPDATE customers SET mob=? WHERE cid=?";
	PreparedStatement preparedstmt=null;
	public void umob(int mob,int cid)
	{
		try
		{
			preparedstmt=conn.prepareStatement(u1);
			preparedstmt.setInt(1, mob);
			preparedstmt.setInt(2, cid);
			preparedstmt.executeUpdate();
		}
		catch(SQLException obb)
		{
			System.err.println("got an exception");
			System.err.println(obb.getMessage());
	    }
	}

}
