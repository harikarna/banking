package customerops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Delid
{
	Connection conn;
	int cid;
	String name;
	int mob;
	String mailid;
	public Delid(Connection conn)
	{
		this.conn=conn;
	}
	String iq="DELETE FROM customers where cid=?";
	PreparedStatement preparedstmt=null;
	public void dvals(int cid)
	{
		try
		{
			preparedstmt=conn.prepareStatement(iq);
			preparedstmt.setInt(1, cid);
			preparedstmt.execute();
			System.out.println("-----Customer deleted successfully-----");
		}
		catch(SQLException ob3)
		{
			System.err.println("got an exception");
			System.err.println(ob3.getMessage());
		}
	}
}
