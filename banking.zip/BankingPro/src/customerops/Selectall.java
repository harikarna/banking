package customerops;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mclasses.Customers;


public class Selectall 
{
	Connection conn;
	int cid;
	String name;
	int mob;
	String mailid;
	public Selectall(Connection conn)
	{
		this.conn=conn;
	}
	Customers ci=new Customers(cid,name,mob,mailid);
	String q="SELECT * FROM customers";
	public void sall()
	{
		try
		{
			PreparedStatement pstmt=conn.prepareStatement(q);
			
			ResultSet rs=pstmt.executeQuery();
			
			System.out.println("CustID"+"\t"+"CustName"+"\t"+"MobileNo"+"\t"+"MailID");
			while(rs.next())
			{
				ci.cid=rs.getInt("cid");
				ci.name=rs.getString("name");
				ci.mob=rs.getInt("mob");
				ci.mailid=rs.getString("mail_id");
				System.out.println(ci.getCid()+"\t"+ci.getName()+"    "+"\t "+ci.getMob()+"\t"+ci.getMailid());
				
			}
			}
			
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
		}

}
