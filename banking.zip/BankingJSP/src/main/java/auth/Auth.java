package auth;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connn.Connect;

public class Auth {
	
	Connect c=new Connect();
	Connection conn=c.gc();
	
	public boolean validate(Login  l)
	{
		boolean status = false;
		String sql = "select * from logins where uname = ? and upwd =?";
		PreparedStatement ps;
		try {
		ps = conn.prepareStatement(sql);
		ps.setString(1, l.getUname());
		ps.setString(2, l.getUpwd());
		ResultSet rs = ps.executeQuery();
		status = rs.next();
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return status;
	}
	}