package auth;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/open")
public class Ls extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
        Auth a1 = new Auth();
        PrintWriter p=response.getWriter();
		String uname = request.getParameter("uname");
		String upwd = request.getParameter("upwd");
		
		HttpSession session = request.getSession();
		session.setAttribute("user", uname);
		
		
		Login l1 = new Login();
		l1.setUname(uname);
		l1.setUpwd(upwd);
		
		if (a1.validate(l1))
		{
		
			
			response.sendRedirect("Home.jsp");
			
		}
		else 
		{
			
			p.println("INVALID CREDENTIALS");
			
		}
	}

}
