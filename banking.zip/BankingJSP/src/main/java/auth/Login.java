package auth;

public class Login 
{
	
	String uname;
	String upwd;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpwd() {
		return upwd;
	}
	public void setUpwd(String upwd2) {
		this.upwd = upwd2;
	}

}
