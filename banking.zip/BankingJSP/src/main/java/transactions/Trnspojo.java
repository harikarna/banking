package transactions;

import java.sql.Connection;

public class Trnspojo 
{
	Connection conn;
	public Trnspojo(int trn_Id, int acc_no, String trn_date, double amount,String comments) {
		
		this.Trn_Id = trn_Id;
		this.acc_no = acc_no;
		this.Trn_date = trn_date;
		this.amount = amount;
		this.comments=comments;
		this.conn=conn;
	}
	public int Trn_Id;
	public int acc_no;
	public String Trn_date;
	public double amount;
	public String comments;
	
	public int getTrn_Id() {
		return Trn_Id;
	}
	public void setTrn_Id(int trn_Id) {
		Trn_Id = trn_Id;
	}
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public String getTrn_date() {
		return Trn_date;
	}
	public void setTrn_date(String trn_date) {
		Trn_date = trn_date;
	}
	public double getAmount() {
		return amount;
	}
	public double setAmount(double amount) {
		return this.amount = amount;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}

}
