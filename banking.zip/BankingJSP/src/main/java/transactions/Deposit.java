package transactions;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import banking.Bankpojo;

import connn.Connect;



@WebServlet("/Deposit")
public class Deposit extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	Connect c=new Connect();
	Connection conn=c.gc();  
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter(); 
		int acc_no=Integer.parseInt(request.getParameter("acc_no"));
		double amount=Double.parseDouble(request.getParameter("amount"));
		String u1="UPDATE banking SET accbal=accbal+"+amount+" WHERE acc_no=?";
		try
		{
			PreparedStatement ps = conn.prepareStatement(u1);
			//ps.setDouble(1, amount);
			ps.setInt(1, acc_no);
			
			ps.executeUpdate();
			out.print("Rs."+amount+" is deposited ");
			//out.print("[Available Balance: "+bs.bbal(acc_no));
		}
		catch(SQLException obb)
		{
			System.err.println("got an exception");
			System.err.println(obb.getMessage());
	    }
		
	}

}
