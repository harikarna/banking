package banking;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Bankserv")
public class Bankserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		String dateofinit=request.getParameter("dateofinit");
		int cid=Integer.parseInt(request.getParameter("cid"));
		int ctg_Id=Integer.parseInt(request.getParameter("ctg_Id"));
		int acc_no=Integer.parseInt(request.getParameter("acc_no"));
		double accbal=Double.parseDouble(request.getParameter("accbal"));
		Bankpojo b=new Bankpojo(acc_no,cid,ctg_Id,dateofinit,accbal);
		request.setAttribute("bank", b);
		RequestDispatcher d=request.getRequestDispatcher("Bdis.jsp");
		if(d!= null)
		{
			d.forward(request, response);
		}
		
	}

}
