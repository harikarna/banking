package banking;

public class Bankpojo 
{
public Bankpojo(int acc_no,int cid, int ctg_Id,String dateofinit,double accbal) {
		
		this.acc_no = acc_no;
		this.cid=cid;
		this.dateofinit = dateofinit;
		this.accbal = accbal;
		this.ctg_Id=ctg_Id;
		
	}
	public int acc_no;
	public String dateofinit;
	public double accbal;
	public int cid;
	public int ctg_Id;
	
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public int getCid() {
		return cid;
	}
	public void Cid(int cid) {
		this.cid = cid;
	}
	public String getDateofinit() {
		return dateofinit;
	}
	public void setDateofinit(String dateofinit) {
		this.dateofinit = dateofinit;
	}
	public double getAccbal() {
		return accbal;
	}
	public double setAccbal(double accbal) {
		return accbal;
	}
	public int getCtg_Id() {
		return ctg_Id;
	}
	public void setCtg_Id(int ctg_Id) {
		this.ctg_Id = ctg_Id;
	}
	@Override
	public String toString() {
		return "Bank Acc Details [acc_no=" + acc_no + ", dateofinit=" + dateofinit + ", accbal=" + accbal + ", cid=" + cid
				+ ", ctg_Id=" + ctg_Id + "]";
	}

}


