package connn;

import java.sql.Connection;

import java.sql.DriverManager;


public class Connect 
{
	Connection conn;
	//String myDriver="com.mysql.cj.jdbc.Driver";
	//String myUrl="jdbc:mysql://localhost:3306/sakila";
	public Connect()
	{}
	public  Connection gc()
	{
		
		try
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","caroot");
		}
		catch(Exception e)
		{
		e.printStackTrace();	
		}
		return conn;
		
		
		
		
		
		
	
}}
