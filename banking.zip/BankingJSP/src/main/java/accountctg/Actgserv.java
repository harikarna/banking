package accountctg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import customer.Custpojo;


@WebServlet("/Actgserv")
public class Actgserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		String category=request.getParameter("category");
		int ctg_Id=Integer.parseInt(request.getParameter("ctg_Id"));
		Accountctgpojo a1=new Accountctgpojo(ctg_Id,category);
		request.setAttribute("actg", a1);
		RequestDispatcher d=request.getRequestDispatcher("Adis.jsp");
		if(d!= null)
		{
			d.forward(request, response);
		}
		
	}

}
