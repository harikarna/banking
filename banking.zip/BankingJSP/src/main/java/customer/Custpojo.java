package customer;

public class Custpojo 
{
	public Custpojo(int cid, String name, int mob, String mailid) {
		
		this.cid = cid;
		this.name = name;
		this.mob = mob;
		this.mailid = mailid;
	}
	int cid;
	String name;
	int mob;
	String mailid;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMob() {
		return mob;
	}
	public void setMob(int mob) {
		this.mob = mob;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	@Override
	public String toString() {
		return "Customer Details [Customer ID=" + cid + ", Name=" + name + ", Mobile-No=" + mob + ", Mail Id=" + mailid + "]";
	}
	

}
