package customer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connn.Connect;



@WebServlet("/Custserv")
public class Custserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connect c=new Connect();
	Connection conn=c.gc();
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		String name=request.getParameter("name");
		String mailid=request.getParameter("mailid");
		int mob=Integer.parseInt(request.getParameter("mob"));
		int cid=Integer.parseInt(request.getParameter("cid"));
		try
		{
			String ic="INSERT INTO customers VALUES (?,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(ic);
			pst.setInt(1, cid);
			pst.setString(2, name);
			pst.setInt(3, mob);
			pst.setString(4, mailid);
			pst.executeUpdate();
			p.println("inserted");
			
		}
		
		catch(Exception e)
		{
			p.println(e);
		}
				
			
		}
		
		

	
		
	}


