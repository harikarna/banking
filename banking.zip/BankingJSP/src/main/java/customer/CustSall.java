package customer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import connn.Connect;


@WebServlet("/CustSall")
public class CustSall extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 

		 Connect c=new Connect();
			Connection conn=c.gc(); 
			
			
		 
	
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		response.setContentType("text/html");
		  PrintWriter out = response.getWriter();
		  
	        
		 

		  String q = "select * from customers";
		  try {
			  PreparedStatement pstmt=conn.prepareStatement(q);
			   ResultSet rs=pstmt.executeQuery();
			  
			   HttpSession session = request.getSession();
		       String uname = (String)session.getAttribute("user");
			   out.println("Hello "+uname+",");   
		   
		   out.println("<html><body><h2>All Customers Info: </h2>");
		   out.println("<hr></br><table cellspacing='0' cellpadding='5' border='1'>");
		   out.println("<tr>");
		   out.println("<td><b>Customer Id</b></td>");
		   out.println("<td><b>Customer Name</b></td>");
		   out.println("<td><b>Mobile No</b></td>");
		   out.println("<td><b>Mail Id</b></td>");
		   out.println("</tr>");

		   while(rs.next()) {
		    out.println("<tr>");
		    out.println("<td>"+rs.getInt(1) + "</td>");
		    out.println("<td>"+rs.getString(2) + "</td>");
		    out.println("<td>"+rs.getInt(3) + "</td>");
		    out.println("<td>"+rs.getString(4) + "</td>");
		    out.println("</tr>");

		   }
		   out.println("</table></br><hr></body></html>");
		  }
		  
		  catch (SQLException e) {

			   e.printStackTrace();
			  }
		  }
	
	 
		  
		 

}
